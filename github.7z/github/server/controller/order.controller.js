const Order = require('../models/order');
const orderCtrl = {};

orderCtrl.getOrders = async (req, res) => {
    const orders = await Order.find();
    res.json(orders);
};

orderCtrl.createOrder = async (req, res) => {
    const order = new Order({
        namePro: req.body.namePro,
        nomProduct: req.body.nomProduct,
        quantity: req.body.quantity
    });
    await order.save();
    res.json({
        'status': 'Order Saved'
    });
};

orderCtrl.getOrder = async (req, res) => {
    const order = await Order.findById();
    res.json(order);
};

orderCtrl.editOrder = async (req, res) => {
    const { id } = req.params;
    const order = {
        namePro: req.body.namePro,
        nomProduct: req.body.nomProduct,
        quantity: req.body.quantity
    };
    await Order.findByIdAndUpdate(id, {$set: order}, {new: true});
    res.json({status: 'Order Updated'});
};

orderCtrl.deleteOrder = async (req, res) => {
    await Order.findByIdAndRemove(req.params.id);
    res.json({status: 'Order Deleted'});
};

module.exports = orderCtrl;