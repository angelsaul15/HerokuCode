const Product = require('../models/product'); 
const productCtrl = {};

productCtrl.getProducts = async (req, res) => {
    const products = await Product.find();
    res.json(products);
};

productCtrl.createProduct = async (req, res) => {
    const product = new Product({
       nomProduct: req.body.nomProduct,
       descriptionP: req.body.descriptionP,
       priceP: req.body.priceP,
       existenceP: req.body.existenceP 
    });
    await product.save();
    res.json({
        'status': 'Product Saved'
    });
};

productCtrl.getProduct = async (req, res) => {
    const product = await Product.findById( );
    res.json(product);
}

productCtrl.editProduct = async (req, res) => {
    const { id } = req.params;
    const product = {
        nomProduct: req.body.nomProduct,
        descriptionP: req.body.descriptionP,
        priceP: req.body.priceP,
        existenceP: req.body.existenceP 
    };
    await Product.findByIdAndUpdate(id, {$set: product}, {new: true});
    res.json({status:'Product Updated'});
};

productCtrl.deleteProduct = async (req, res) => {
    await Product.findByIdAndRemove(req.params.id);
    res.json({ status: 'Product Deleted'});
};

module.exports = productCtrl;