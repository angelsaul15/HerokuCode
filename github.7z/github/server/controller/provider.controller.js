const Provider = require('../models/provider');
const providerCtrl = {};

providerCtrl.getProviders = async (req, res) => {
    const providers =  await Provider.find();
    res.json(providers);
};

providerCtrl.createProvider = async (req, res) => {
    const provider = new Provider({
        nameP: req.body.nameP,
        productsP: req.body.productsP,
        emailP: req.body.emailP,
        celphoneP: req.body.celphoneP
    });
    await provider.save();
    res.json({
        'status': 'Provider Saved'
    });
};

providerCtrl.getProvider = async (req, res) => {
    const provider = await Provider.findById( );
    res.json(provider);
};

providerCtrl.editProvider = async (req, res) => {
    const { id } = req.params;
    const provider = {
        nameP: req.body.nameP,
        productsP: req.body.productsP,
        emailP: req.body.emailP,
        celphoneP: req.body.celphoneP
    };
    await Provider.findByIdAndUpdate(id, {$set: provider}, {new: true});
    res.json({status: 'Provider Updated'});
};

providerCtrl.deleteProvider = async (req, res) => {
    await Provider.findByIdAndRemove(req.params.id);
    res.json({status: 'Provider Deleted'});
}

module.exports = providerCtrl;