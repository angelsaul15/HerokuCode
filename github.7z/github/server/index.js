const express = require('express'),
    path = require('path'),
    morgan = require('morgan'),
    cors = require('cors'),
    bodyParser = require('body-parser');

const app = express();
require('dotenv').config();
require('./database');

// Middlewares
app.use(bodyParser.json());
app.use(morgan('dev'));
app.use(express.json());
app.use(cors());

//Routes
app.use(express.static('./dist/mean-lunadequeso'));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/dist/mean-lunadequeso/server/index.js'));
});
app.use(process.env.URL_ORDER, require('./routes/order.routes'));
app.use(process.env.URL_CLIENT, require('./routes/client.routes'));
app.use(process.env.URL_PRODUCT, require('./routes/product.routes'));
app.use(process.env.URL_PROVIDER, require('./routes/provider.routes'));

//Starting the server
app.listen(process.env.PORT, () => {
    console.log(`Server started in ${process.env.PORT}`);
});