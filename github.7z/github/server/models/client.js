const mongoose = require('mongoose');
const { Schema } = mongoose;

const ClientSchema = new Schema({
    nameC: { type: String, required: true },
    addressC: { type: String, required: true },
    emailC: { type: String, required: true },
    celphoneC: { type: Number, required: true },
    creditC: { type: Number, required: true }
});

module.exports = mongoose.model('Client', ClientSchema);