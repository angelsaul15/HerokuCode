const mongoose = require('mongoose');
const { Schema } = mongoose;
const namePro = require('./provider');
const nomProduct = require('./product');

const OrderSchema = new Schema ({
    namePro: { type: Schema.Types.ObjectId, ref: 'namePro', required: true },
    nomProduct: { type: Schema.Types.ObjectId, ref: 'nomProduct', required: true },
    quantity: { type: Number, required: true }
});

module.exports = mongoose.model('Order', OrderSchema);