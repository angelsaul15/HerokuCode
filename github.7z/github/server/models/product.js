const mongoose = require('mongoose');
const { Schema } = mongoose;

const ProductSchema = new Schema({
    nomProduct: { type: String, required: true },
    descriptionP: { type: String, required: true },
    priceP: { type: Number, required: true },
    existenceP: { type: Number, required: true}
});

module.exports = mongoose.model('Product', ProductSchema);