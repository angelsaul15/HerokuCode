const mongoose = require('mongoose');
const { Schema } = mongoose;

const ProviderSchema = new Schema({
    nameP: { type: String, required: true },
    productsP: { type: String, required: true },
    emailP: { type: String, required: true },
    celphoneP: { type: Number, required: true }
});

module.exports = mongoose.model('Provider', ProviderSchema);