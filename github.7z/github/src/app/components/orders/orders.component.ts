import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../services/order.service';
import { NgForm } from '@angular/forms';
import { Order } from 'src/app/models/order';
import { Provider } from 'src/app/models/provider';
import { Product } from 'src/app/models/product';


declare var M: any;

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css'],
  providers: [OrderService]
})
export class OrdersComponent implements OnInit {

  constructor(public orderService: OrderService) { }

  ngOnInit() {
    this.getOrders();
  }

  addOrder(form: NgForm){
    if(form.value._id){
      this.orderService.putOrder(form.value)
      .subscribe(res =>{
        this.resetForm(form);
        M.toast({html: 'Updated Successfully'});
        this.getOrders();
      });
    }else{
      console.log(form.value);
      this.orderService.postOrder(form.value)
      .subscribe(res => {
        this.resetForm(form);
        M.toast({html: 'Order Saved Successfully'});
        this.getOrders();
      });
    }
  }

  getOrders(){
    this.orderService.getOrders()
    .subscribe(res => {
      this.orderService.order = res as Order[];
      console.log(res);
    });
  }

  editOrder(order: Order){
    this.orderService.selectedOrder = order;
  }

  deleteOrder(_id: string){
    if(confirm('Are you sure you wnat to delete it?')){
      this.orderService.deleteOrder(_id)
      .subscribe(res => {
        this.getOrders();
        M.toast({html: 'Deleted Successfully'});
      });
    }
  }

  resetForm(form?: NgForm){
    if(form){
      form.reset();
      this.orderService.selectedOrder = new Order();
    }
  }
} 
