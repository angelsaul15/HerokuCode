import { Component, OnInit } from '@angular/core';
import { ProviderService } from '../../services/provider.service';
import { NgForm } from '@angular/forms';
import { Provider } from 'src/app/models/provider';

declare var M: any;

@Component({
  selector: 'app-providers',
  templateUrl: './providers.component.html',
  styleUrls: ['./providers.component.css'],
  providers: [ProviderService]
})
export class ProvidersComponent implements OnInit {

  constructor(public providerService: ProviderService) { }

  ngOnInit() {
    this.getProviders();
  }

  addProvider(form: NgForm){
    if(form.value._id){
      this.providerService.putProvider(form.value)
      .subscribe(res =>{
        this.resetForm(form);
        M.toast({html: 'Updated Successfuly'});
        this.getProviders();
      });
    }else{
      this.providerService.postProvider(form.value)
      .subscribe(res =>{
        this.resetForm(form);
        M.toast({html: 'Save Successfuly'});
        this.getProviders();
      });
    }
  }

  getProviders(){
    this.providerService.getProviders()
    .subscribe(res =>{
      this.providerService.provider = res as Provider[];
      console.log(res);
    });
  }

  editProvider(provider: Provider){
    this.providerService.selectedProvider = provider;
  }
 
  deleteProvider(_id: string){
    if(confirm('Are you sure you wnat to delete it?')){
      this.providerService.deleteProvider(_id)
      .subscribe(res => {     
        this.getProviders();
        M.toast({html: 'Deleted successfully'});
      });
    }
  }

  resetForm(form?: NgForm){
    if(form){
      form.reset();
      this.providerService.selectedProvider = new Provider();
    }
  }

}
