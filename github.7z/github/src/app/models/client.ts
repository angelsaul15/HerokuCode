export class Client {

    constructor(_id = '', nameC = '', addressC = '', emailC = '', celphoneC = 0, creditC = 0){
        this._id = _id;
        this.nameC = nameC;
        this.addressC = addressC;
        this.emailC = emailC;
        this.celphoneC = celphoneC;
        this.creditC = creditC;
    }

    _id: string;
    nameC: string;
    addressC: string;
    emailC: string;
    celphoneC: number;
    creditC: number; 
} 
