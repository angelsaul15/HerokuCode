import { Product } from './product';
import { Provider } from './provider';

export class Order {

    constructor(_id = '', namePro = new Provider(), nomProduct = new Product(), quantity = 0){
        this._id = _id;
        this.namePro = namePro;
        this.nomProduct = nomProduct;
        this.quantity = quantity;
    }

    _id: string;
    namePro: Provider;
    nomProduct: Product;
    quantity: number;

}
