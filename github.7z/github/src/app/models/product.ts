export class Product {
    constructor(_id = '', nomProduct = '', descriptionP = '', priceP = 0, existenceP = 0){
        this._id = _id;
        this.nomProduct = nomProduct;
        this.descriptionP = descriptionP;
        this.priceP = priceP;
        this.existenceP = existenceP;
    }

    _id: string;
    nomProduct: string;
    descriptionP: string;
    priceP: number;
    existenceP: number;
}
