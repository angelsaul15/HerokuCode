export class Provider {

    constructor(_id = '', nameP = '', productsP = '', emailP = '', celphoneP = 0){
        this._id = _id;
        this.nameP = nameP;
        this.productsP = productsP;
        this.emailP = emailP;
        this.celphoneP = celphoneP;
    }

    _id: string; 
    nameP: string;
    productsP: string;
    emailP: string;
    celphoneP: number;

}
