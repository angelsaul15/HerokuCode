import { NgModule } from '@angular/core';
import { RouterModule, Routes } from "@angular/router";

import { AppComponent } from '../app.component';

//Catalogos
import { ClientsComponent } from '../components/clients/clients.component';
import { ProductsComponent } from '../components/products/products.component';
import { ProvidersComponent } from '../components/providers/providers.component';
import { OrdersComponent } from '../components/orders/orders.component';

const routes: Routes = [
    {path: 'home', component: AppComponent},
    {path: 'clients', component: ClientsComponent},
    {path: 'products', component: ProductsComponent},
    {path: 'providers', component:ProvidersComponent},
    {path: 'orders', component:OrdersComponent}
]

@NgModule({
    declarations: [],
    imports:[
        RouterModule.forRoot(routes),
    ],
    exports:[RouterModule],
})

export class RouteModule {}