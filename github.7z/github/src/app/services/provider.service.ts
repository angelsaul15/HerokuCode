import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Provider } from '../models/provider';

@Injectable({
  providedIn: 'root'
})
export class ProviderService {

  selectedProvider: Provider;
  provider: Provider[]; 
  readonly URL_API = 'http://localhost:3000/api/providers';
  //readonly URL_API = '/api/providers';

  constructor(public http: HttpClient) { 
    this.selectedProvider = new Provider();
  }

  getProviders() {
    return this.http.get(this.URL_API);
  }

  postProvider(Provider: Provider) { 
    return this.http.post(this.URL_API, Provider);
  }

  putProvider(provider: Provider){
    return this.http.put(this.URL_API + `/${provider._id}`, provider);
  }

  deleteProvider(_id: string){
    return this.http.delete(this.URL_API + `/${_id}`);
  }
}
